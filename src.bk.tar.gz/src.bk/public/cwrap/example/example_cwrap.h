#ifndef __EXAMPLE_CWRAP_H__
#define __EXAMPLE_CWRAP_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef void* Tag;
Tag tag_new();
void tag_free(Tag p);
int tag_report(Tag p, int xi, int xj, int yi, int yj);

void tag_set_ip(Tag p, char *ip);
void tag_set_port(Tag p, unsigned int port);

char* tag_get_ip(Tag p);
unsigned int tag_get_port(Tag p);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __EXAMPLE_CWRAP_H__ */

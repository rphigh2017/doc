package example

// #include <stdlib.h>
// #include "example_cwrap.h"
// #cgo CFLAGS: -g -Wall
// #cgo CPPFLAGS: -g -Wall
// #cgo LDFLAGS:${SRCDIR}/libexample_cwrap.a -lstdc++
import "C"
import (
    "unsafe"
)

// Tag ...
type Tag struct {
    t C.Tag
}

// New ...
func (p *Tag) Init(host string, port int) {
    p.t = C.tag_new()
    p.SetHost(host)
    p.SetPort(port)
}

// Free ...
func (p *Tag) Free() {
    C.tag_free(p.t)
}

// Report ...
func (p Tag) Report(xi, xj, yi, yj int) ReportFunc {
    x1, x2, y1, y2 := C.int(xi), C.int(xj), C.int(yi), C.int(yj)
    return func() {
        C.tag_report(p.t, x1, x2, y1, y2)
    }
}

// SetHost ...
func (p *Tag) SetHost(host string) {
    h := C.CString(host)
    defer C.free(unsafe.Pointer(h))
    C.tag_set_ip(p.t, h)
}

// SetPort ...
func (p *Tag) SetPort(port int) {
    C.tag_set_port(p.t, C.uint(port))
}

// GetHost ...
func (p Tag) GetHost() string {
    return C.GoString(C.tag_get_ip(p.t))
}

// GetPort ...
func (p Tag) GetPort() int {
    return int(C.tag_get_port(p.t))
}

type ReportFunc func()

var XReport ReportFunc
var YReport ReportFunc

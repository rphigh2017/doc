#include "example.hpp"
#include "example_cwrap.h"

Tag tag_new() {
    tag *p = new tag();
    return (Tag)p;
}

void tag_free(Tag p) {
    tag *q = (tag*) p;
    delete q;
}

int tag_report(Tag p, int xi, int xj, int yi, int yj) {
    tag *q = (tag*)p;
    return report(*q, xi, xj, yi, yj);
}

void tag_set_ip(Tag p, char *ip) {
    ((tag*)p)->host.assign(ip);
}

void tag_set_port(Tag p, unsigned int port) {
    ((tag*)p)->port = port;
}

char* tag_get_ip(Tag p) {
    return (char*)(((tag*)p)->host.c_str());
}
unsigned int tag_get_port(Tag p) {
    return ((tag*)p)->port;
}

#include <iostream>
#include "example.hpp"

using namespace std;

int report(tag& t, int xi, int xj, int yi, int yj, struct timeval* tm) {
    cout << __FUNCTION__ << "[" <<  __LINE__ << "]" << ":"
         << xi << "." << xj << "." << yi << yj << " "
         << t.host << "@"
         << t.port << endl;
    return 0;
};

#ifndef __EXAMPLE_HPP__
#define __EXAMPLE_HPP__

#include <sys/time.h>
#include <string>

using namespace std;

typedef struct tag {
    string  host;
    unsigned short  port;
} tag;

int report(tag& t, int xi, int xj, int yi, int yj, struct timeval* tm=NULL);

#endif /* __EXAMPLE_HPP__ */

package example

import (
    "fmt"
    "testing"
)

func TestTag(t *testing.T) {
    p := &Tag{}
    p.Init("1.1.1.1", 12345)
    defer p.Free()

    XReport = p.Report(1,2,3,4)
    XReport()
    fmt.Println(p.GetHost(), p.GetPort())

    YReport = p.Report(5,6,7,8)
    YReport()
    fmt.Println(p.GetHost(), p.GetPort())
}

package util

import (
	"encoding/json"
    "net"
)

func ToJsonString(data interface{}) string {
	bs, _ := json.MarshalIndent(data, "", "  ")
	return string(bs)
}

func GetIPFromETH(eth string) string {
    ethx, _ := net.InterfaceByName(eth)
    addrs, _ := ethx.Addrs()
    tcpAddr := net.TCPADDR{IP: addrs[0].(*net.IPNet.IP}
    return tcpAddr.IP.String()
}

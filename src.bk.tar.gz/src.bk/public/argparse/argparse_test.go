package argparse

import (
	"fmt"
	"public/util"
	"testing"
)

type Option struct {
	Int    int               `default:"123"`
	Str    string            `default:"str"`
	IntVec []int             `default:"1;2;3"`
	StrVec []string          `default:"str1;str2;str3"`
	IntSet map[int]bool      `default:"4;5;6"`
	StrSet map[string]bool   `default:"str4;str5;str6"`
	IIMap  map[int]int       `default:"1:2;3:4;5:6"`
	SSMap  map[string]string `default:"str1:str2;str3:str4"`
	ISMap  map[int]string    `default:"1:str1;2:str2"`
	SIMap  map[string]int    `default:"str1:1;str2:2"`

	LogLevel int `default:"0"`
}

var option Option

func TestArg(t *testing.T) {
	a := Arg("LogLevel=3")
	a.Unmarshal(&option)
	fmt.Println(util.ToJsonString(&option))
}

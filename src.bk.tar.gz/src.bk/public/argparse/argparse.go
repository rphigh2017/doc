package argparse

import (
	"log"
	"net/url"
	"reflect"
	"strconv"
	"strings"
)

// Arg ...
type Arg string

// Unmarshal ...
func (p Arg) Unmarshal(data interface{}) {
	kv, _ := url.ParseQuery(string(p))

	val := reflect.ValueOf(data).Elem()
	typ := val.Type()

	for i := 0; i < val.NumField(); i++ {
		v := val.Field(i)
		t := typ.Field(i)
		// v.Type(), v.Interface(), t.Name, t.Tag, t.Tag.Get("xml")
		k := t.Name
		vstr := t.Tag.Get("default")
		if v1, ok := kv[k]; ok {
			vstr = strings.Join(v1, ";")
		}
		vstr = strings.Trim(vstr, ";")
		switch v.Interface().(type) {
		case int:
			int1, _ := strconv.Atoi(vstr)
			val.Field(i).SetInt(int64(int1))
		case string:
			val.Field(i).SetString(vstr)
		case []int, []string:
			vec1 := strings.Split(vstr, ";")
			val.Field(i).Set(reflect.MakeSlice(v.Type(), len(vec1), len(vec1)))
			for j, x := range vec1 {
				switch v.Interface().(type) {
				case []int:
					int1, _ := strconv.Atoi(x)
					val.Field(i).Index(j).Set(reflect.ValueOf(int1))
				case []string:
					val.Field(i).Index(j).Set(reflect.ValueOf(x))
				}
			}
		case map[int]bool, map[string]bool:
			set1 := strings.Split(vstr, ";")
			val.Field(i).Set(reflect.MakeMap(v.Type()))
			for _, x := range set1 {
				switch v.Interface().(type) {
				case map[int]bool:
					int1, _ := strconv.Atoi(x)
					val.Field(i).SetMapIndex(reflect.ValueOf(int1), reflect.ValueOf(true))
				case map[string]bool:
					val.Field(i).SetMapIndex(reflect.ValueOf(x), reflect.ValueOf(true))
				}
			}
		case map[int]int, map[string]string, map[int]string, map[string]int:
			map1 := strings.Split(vstr, ";")
			val.Field(i).Set(reflect.MakeMap(v.Type()))
			for _, x := range map1 {
				map1 := strings.Split(x, ":")
				if len(map1) != 2 {
					log.Println(t.Name, vstr, x, "error")
					continue
				}
				switch v.Interface().(type) {
				case map[int]int:
					k1, _ := strconv.Atoi(map1[0])
					v1, _ := strconv.Atoi(map1[1])
					val.Field(i).SetMapIndex(reflect.ValueOf(k1), reflect.ValueOf(v1))
				case map[string]string:
					val.Field(i).SetMapIndex(reflect.ValueOf(map1[0]), reflect.ValueOf(map1[1]))
				case map[int]string:
					k1, _ := strconv.Atoi(map1[0])
					val.Field(i).SetMapIndex(reflect.ValueOf(k1), reflect.ValueOf(map1[1]))
				case map[string]int:
					v1, _ := strconv.Atoi(map1[1])
					val.Field(i).SetMapIndex(reflect.ValueOf(map1[0]), reflect.ValueOf(v1))
				}
			}
		default:
		}
	}
}

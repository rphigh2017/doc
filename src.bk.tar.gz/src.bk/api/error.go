package api

// const
const (
	ErrorConnect         = iota + 10000
	ErrorWrite
	ErrorRead
	ErrorReadPkgHeader
	ErrorReadPkgLarge
	ErrorFreeConnTimeout
)

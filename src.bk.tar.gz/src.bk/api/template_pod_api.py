#!/usr/bin/env python
# -*- coding: utf8 -*-

base = '''
package {PKG_NAME}

import "time"
import "errors"
import "api"
import "api/header/pod"

// {FUNC_NAME} ...
func {FUNC_NAME}(d1 []byte, r *api.Routor, m *api.Monitor) ([]byte, int, error) {{
    var req pod.ReqHeader
    req.SetCommand({COMMAND})
    req.SetSeqNum({SEQNUM})
    var rsp pod.RspHeader
    var d2 []byte
    ipt, ret, err := r.Select()
    if err != nil {{
        m.Report(0, 1, 2, 3, 100, ret, "127.0.0.1")
        return nil, ret, err
    }}

    t1 := time.Now().UnixNano()
    ret, err = api.SendAndRecv(ipt, &req, d1, &rsp, d2)
    t2 := time.Now().UnixNano()
    cost := int((t2 - t1) / 1000) // us
    if err != nil {{
        r.Update(ipt.IP, ipt.Port, ret, cost)
        m.Report(0, 1, 2, 3, cost, ret, "127.0.0.1")
        return nil, ret, err
    }}

    ret = int(rsp.GetResult())
    if ret != 0 {{
        r.Update(ipt.IP, ipt.Port, ret, cost)
        m.Report(0, 1, 2, 3, cost, ret, "127.0.0.1")
        return nil, ret, errors.New("Logic error")
    }}

    r.Update(ipt.IP, ipt.Port, 0, cost)
    m.Report(0, 1, 2, 3, cost, 0, "127.0.0.1")
    return rsp.Decode(d2), 0, nil
}}
'''

package main

import (
	"api"
	"api/header"
	"api/header/pod"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"public/argparse"
	"public/util"
	"runtime"
	"time"
)

// Option ...
type Option struct {
	LocalIP      string `default:"127.0.0.1"`
	ListenPort   string `default:":8080"`
	LogFile      string `default:"/usr/local/service/xxx/log`
	LogLevel     string `default:"3"`
	RecvInitSize int32  `default:"4096"`
	RecvMaxSize  int32  `default:"65535"`
	RecvTimeout  int    `default:"600000"` // ms
	SendTimeout  int    `default:"1000"`   // ms
}

var option Option

func init() {
	query := flag.String("Query", "", "")

	flag.Parse()

	q := argparse.Arg(*query)
	q.Unmarshal(&option)

	fmt.Println(util.ToJsonString(&option))
	log.Println(util.ToJsonString(&option))

	HookInit()
}

func main() {
	fmt.Println("start to listen " + option.ListenPort)
	log.Println("start to listen " + option.ListenPort)

	defer func() {
		if err := recover(); err != nil {
			const size = 64 << 10
			buf := make([]byte, size)
			buf = buf[:runtime.Stack(buf, false)]
			log.Println("service panic:\n%s", string(buf))
		}
	}()

	addr, err := net.ResolveTCPAddr("tcp", option.LocalIP+option.ListenPort)
	if err != nil {
		fmt.Println(err)
		log.Fatal(err)
	}

	listener, err := net.ListenTCP("tcp", addr)
	if err != nil {
		fmt.Println(err)
		log.Fatal(err)
	}

	for {
		conn, err := listener.AcceptTCP()
		if err != nil {
			log.Println(err)
			continue
		}
		go HookRun(conn)
	}
}

// HookInit ...
func HookInit() {
}

// HookInput ...
func HookInput(conn *net.TCPConn, head header.Header) ([]byte, int) {
	buf := make([]byte, option.RecvInitSize)
	pos := 0
	expand := false

	for {
		size, err := conn.Read(buf[pos:])
		if err != nil {
			if err != io.EOF {
				log.Println(err)
			}
			return nil, api.ErrorFreeConnTimeout
		}
		pos += size
		reallen, ret := head.Right(buf[:pos])
		if ret < 0 {
			return nil, api.ErrorReadPkgHeader
		}
		if reallen > option.RecvMaxSize {
			return nil, api.ErrorReadPkgLarge
		}
		if reallen > option.RecvInitSize && !expand {
			tmp := make([]byte, reallen)
			copy(tmp, buf)
			buf = tmp
			expand = true
		}
	}

	return buf[:pos], 0
}

// HookRun ...
func HookRun(conn *net.TCPConn) {
	defer func() {
		if err := recover(); err != nil {
			const size = 64 << 10
			buf := make([]byte, size)
			buf = buf[:runtime.Stack(buf, false)]
			log.Println("service panic:\n%s", string(buf))
		}
		conn.Close()
	}()

	for {
		var req pod.ReqHeader
		var rsp pod.RspHeader

		current := time.Now()
		conn.SetReadDeadline(current.Add(time.Duration(option.RecvTimeout) * time.Millisecond))
		buf, ret := HookInput(conn, &req)
		rsp.SetCommand(req.GetCommand())
		rsp.SetSeqNum(req.GetSeqNum())
		if ret != 0 {
			rsp.SetResult(int32(ret))

			current = time.Now()
			conn.SetWriteDeadline(current.Add(time.Duration(option.SendTimeout) * time.Millisecond))
			if _, err := conn.Write(rsp.Encode([]byte{})); err != nil {
				log.Println(err)
			}
			return
		}

		ins := req.Decode(buf)
		var outs []byte
		switch req.GetCommand() {
		case XTestGet:
			outs, ret = TestGet(ins)
		case XTestSet:
			outs, ret = TestSet(ins)
		default:
		}

		rsp.SetResult(int32(ret))
		if ret != 0 {
			outs = []byte{}
		}
		current = time.Now()
		conn.SetWriteDeadline(current.Add(time.Duration(option.SendTimeout) * time.Millisecond))
		if _, err := conn.Write(rsp.Encode(outs)); err != nil {
			log.Println(err)
			return
		}
	}
}

// const
const (
	XTestGet = iota + 100
	XTestSet
)

// TestGet ...
func TestGet(ins []byte) ([]byte, int) {
	return []byte("TestGet"), 0
}

// TestSet ...
func TestSet(ins []byte) ([]byte, int) {
	return []byte("TestSet"), 0
}

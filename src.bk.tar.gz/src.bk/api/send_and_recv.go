package api

import (
	"api/header"
    "fmt"
    "net"
    "time"
    "errors"
)

// Monitor ...
type Monitor struct {
    monitor string
}

func (p *Monitor) Report(p1, f1, p2, f2 int, cost, ret int, ip string) {
}

// Routor ...
type Routor struct {
    route string
	ConnectTimeout int
	ReadTimeout    int
	WriteTimeout   int
}

func (p *Routor) Init(r string) {
    p.route = r
}

func (p Routor) Select() (*IPPortTimeout, int, error) {
    return &IPPortTimeout{"127.0.0.1", 6789, 100, 100, 100}, 0, nil
}

func (p Routor) Update(ip string, port, ret, cost int) {
}

// IPPortTimeout ...
type IPPortTimeout struct {
	IP             string
	Port           int
	ConnectTimeout int
	ReadTimeout    int
	WriteTimeout   int
}

// const
const (
	MinBufSize = 1024
	MaxBufSize = 1024 * 1024 * 1
)

// SendAndRecv ...
func SendAndRecv(ipt *IPPortTimeout, h1 header.Header, d1 []byte, h2 header.Header, d2 []byte) (int, error) {
	dst := fmt.Sprintf("%s:%d", ipt.IP, ipt.Port)
	conn, err := net.DialTimeout("tcp", dst, time.Duration(ipt.ConnectTimeout)*time.Millisecond)
	if err != nil {
		return ErrorConnect, err
	}
	defer conn.Close()

	conn.SetWriteDeadline(time.Now().Add(time.Duration(ipt.WriteTimeout) * time.Millisecond))
	_, err = conn.Write(h1.Encode(d1))
	if err != nil {
		return ErrorWrite, err
	}

	conn.SetReadDeadline(time.Now().Add(time.Duration(ipt.ReadTimeout) * time.Millisecond))
	buf := make([]byte, MinBufSize)
	pos := 0
	expand := false
	for {
		size, err := conn.Read(buf[pos:])
		if err != nil {
			return ErrorRead, err
		}
		pos += size
		reallen, ret := h2.Right(buf[:pos])
		if ret < 0 {
			return ErrorReadPkgHeader, errors.New("package header error")
		}
		if ret > 0 {
			break
		}
		if reallen > MaxBufSize {
			return ErrorReadPkgLarge, errors.New("package too large")
		}
		if reallen > MinBufSize && !expand {
			tmp := make([]byte, reallen)
			copy(tmp, buf)
			buf = tmp
			expand = true
		}
	}

	d2 = h2.Decode(buf[:pos])
	return 0, nil
}

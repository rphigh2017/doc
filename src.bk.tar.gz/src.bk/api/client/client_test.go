package client

import (
	"api"
    "api/protocol"
	"encoding/json"
	"log"
	"testing"
)

func TestClient(t *testing.T) {
	r := &api.Routor{}
	m := &api.Monitor{}

	h := &protocol.HelloReq{H: "H", E: "E", L: "L"}
	w := protocol.WorldRsq{}

	d1, _ := json.Marshal(h)
	d2, ret, err := Client(d1, r, m)
	if err == nil && ret == 0 {
		json.Unmarshal(d2, &w)
		log.Println(w)
	}
}

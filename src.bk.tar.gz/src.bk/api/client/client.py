#!/usr/bin/env python
# -*- coding: utf8 -*-

import sys
sys.path.append("..")

import template_pod_api as T

table = {
        'PKG_NAME' : 'client',
        'FUNC_NAME' : 'Client',
        'COMMAND' : 1289,
        'SEQNUM' : 101
        }

if __name__ == "__main__":
    print(T.base.format(**table))

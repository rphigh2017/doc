package protocol

type HelloReq struct {
	H string
	E string
	L string
}

type WorldRsq struct {
	W string
	O string
	R string
}

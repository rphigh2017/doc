package header

// Header ...
type Header interface {
	Encode([]byte) []byte
	// = 0: continue
	// < 0: error
	// > 0: finish
	Right([]byte) (reallen int32, ret int32)
	Decode([]byte) []byte

	GetSeqNum() int32
	GetCommand() int32
	GetResult() int32

	SetSeqNum(int32)
	SetCommand(int32)
	SetResult(int32)
}

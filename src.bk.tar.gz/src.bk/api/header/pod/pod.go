package pod

import (
	"bytes"
	"encoding/binary"
)

// const
const (
	S                  = byte('S')
	Y                  = byte('Y')
	N                  = byte('N')
	A                  = byte('A')
	C                  = byte('C')
	K                  = byte('K')
	Version            = byte(0x01)
	ReqHeaderFixedSize = 16
	RspHeaderFixedSize = 20
)

// ReqHeader ...
type ReqHeader struct {
	S       byte
	Y       byte
	N       byte
	version byte
	length  int32
	seqnum  int32
	command int32
}

// Encode ...
func (p *ReqHeader) Encode(data []byte) []byte {
	p.S = S
	p.Y = Y
	p.N = N
	p.version = Version
	p.length = int32(len(data))

	buf := new(bytes.Buffer)
	binary.Write(buf, binary.BigEndian, p.S)
	binary.Write(buf, binary.BigEndian, p.Y)
	binary.Write(buf, binary.BigEndian, p.N)
	binary.Write(buf, binary.BigEndian, p.version)
	binary.Write(buf, binary.BigEndian, p.length)
	binary.Write(buf, binary.BigEndian, p.seqnum)
	binary.Write(buf, binary.BigEndian, p.command)
	binary.Write(buf, binary.LittleEndian, data)

	return buf.Bytes()
}

// Right ...
func (p *ReqHeader) Right(data []byte) (int32, int32) {
	l := int32(len(data))
	if l < ReqHeaderFixedSize {
		return 0, 0
	}

	buf := bytes.NewReader(data)
	binary.Read(buf, binary.BigEndian, &p.S)
	binary.Read(buf, binary.BigEndian, &p.Y)
	binary.Read(buf, binary.BigEndian, &p.N)
	binary.Read(buf, binary.BigEndian, &p.version)
	binary.Read(buf, binary.BigEndian, &p.length)
	binary.Read(buf, binary.BigEndian, &p.seqnum)
	binary.Read(buf, binary.BigEndian, &p.command)

	if p.S != S || p.Y != Y || p.N != N {
		return 0, -1
	}
	if p.version != Version {
		return 0, -2
	}
	if l < ReqHeaderFixedSize+p.length {
		return ReqHeaderFixedSize + p.length, 0
	}

	return l, l
}

// Decode ...
func (p *ReqHeader) Decode(data []byte) []byte {
	return data[ReqHeaderFixedSize : ReqHeaderFixedSize+p.length]
}

// GetSeqNum ...
func (p *ReqHeader) GetSeqNum() int32 {
	return p.seqnum
}

// GetCommand ...
func (p *ReqHeader) GetCommand() int32 {
	return p.command
}

// GetResult ...
func (p *ReqHeader) GetResult() int32 {
	return 0
}

// SetSeqNum ...
func (p *ReqHeader) SetSeqNum(i int32) {
	p.seqnum = i
}

// SetCommand ...
func (p *ReqHeader) SetCommand(i int32) {
	p.command = i
}

// SetResult ...
func (p *ReqHeader) SetResult(i int32) {
}

// RspHeader ...
type RspHeader struct {
	A       byte
	C       byte
	K       byte
	version byte
	length  int32
	seqnum  int32
	command int32
	result  int32
}

// Encode ...
func (p *RspHeader) Encode(data []byte) []byte {
	p.A = A
	p.C = C
	p.K = K
	p.version = Version
	p.length = int32(len(data))

	buf := new(bytes.Buffer)
	binary.Write(buf, binary.BigEndian, p.A)
	binary.Write(buf, binary.BigEndian, p.C)
	binary.Write(buf, binary.BigEndian, p.K)
	binary.Write(buf, binary.BigEndian, p.version)
	binary.Write(buf, binary.BigEndian, p.length)
	binary.Write(buf, binary.BigEndian, p.seqnum)
	binary.Write(buf, binary.BigEndian, p.command)
	binary.Write(buf, binary.BigEndian, p.result)
	binary.Write(buf, binary.LittleEndian, data)

	return buf.Bytes()
}

// Right ...
func (p *RspHeader) Right(data []byte) (int32, int32) {
	l := int32(len(data))
	if l < RspHeaderFixedSize {
		return 0, 0
	}

	buf := bytes.NewReader(data)
	binary.Read(buf, binary.BigEndian, &p.A)
	binary.Read(buf, binary.BigEndian, &p.C)
	binary.Read(buf, binary.BigEndian, &p.K)
	binary.Read(buf, binary.BigEndian, &p.version)
	binary.Read(buf, binary.BigEndian, &p.length)
	binary.Read(buf, binary.BigEndian, &p.seqnum)
	binary.Read(buf, binary.BigEndian, &p.command)
	binary.Read(buf, binary.BigEndian, &p.result)

	if p.A != A || p.C != C || p.K != K {
		return 0, -1
	}
	if p.version != Version {
		return 0, -2
	}
	if l < RspHeaderFixedSize+p.length {
		return RspHeaderFixedSize + p.length, 0
	}

	return l, l
}

// Decode ...
func (p *RspHeader) Decode(data []byte) []byte {
	return data[RspHeaderFixedSize : RspHeaderFixedSize+p.length]
}

// GetSeqNum ...
func (p *RspHeader) GetSeqNum() int32 {
	return p.seqnum
}

// GetCommand ...
func (p *RspHeader) GetCommand() int32 {
	return p.command
}

// GetResult ...
func (p *RspHeader) GetResult() int32 {
	return p.result
}

// SetSeqNum ...
func (p *RspHeader) SetSeqNum(i int32) {
	p.seqnum = i
}

// SetCommand ...
func (p *RspHeader) SetCommand(i int32) {
	p.command = i
}

// SetResult ...
func (p *RspHeader) SetResult(i int32) {
	p.result = i
}

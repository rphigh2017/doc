// input_size|max_len[|def_val]
regexp.MatchString(`^\d+\|\d+(\|\d+)?$`, s)
// size
regexp.MatchString(`\d+(\|\d+)*$`, s)
// LIST:val_0|name_0,val_1|name_1,... ...
regexp.MatchString(`^LIST:(.*?\|.*?,)*(.*?\|.*?),?$`, s)
// SQL:host|user|pwd|name|utf8|utf8|select $k1,$k2 from t where w
`SQL:(.*?\|){4,4}\d+\|\d+\|select.*?from.*?(where.*?)?`

t, err := template.ParseFiles("home.html")
t.Execute(w, err)

fd, err := os.OpenFile(fn, os.O_CREATE|os.O_RDWR|os.O_APPEND, os.ModePerm)

func Int64(req *http.Request, name string, def ...int64) int64 {
    i, err := strconv.ParseInt(req.FormValue(name), 10, 64)
    if err != nil {
        if len(def) > 0 {
            return def[0]
        }
        return int64(0)
    }
    return i
}

req.URL.Path

func FileCopy(dst, src string) error {
    srcFile, err := os.Open(src)
    if err != nil {
        return err
    }
    defer srcFile.Close()

    dstFile, err := os.Create(dst)
    if err != nil {
        return err
    }
    defer dstFile.Close()

    _, err = io.Copy(dstFile, srcFile)
    return err
}

func FileSize(src string) (int64, error) {
    info, err := os.Stat(src)
    if err != nil {
        return 0, err
    }
    return info.Size(), nil
}

func FileMD5(src string) (string, error) {
    fmd5 := ""
    srcFile, err := os.Open(src)
    if err != nil {
        return fmd5, err
    }
    m := md5.New()
    io.Copy(h, srcFile)
    return fmt.Sprintf("%x", h.Sum([]byte(""))), nil
}

err == sql.ErrNoRows
driver.ErrBadConn

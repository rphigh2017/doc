func SQLGet(db *sql.DB, sql string) ([]map[string]interface{}, error) {
    res := make([]map[string]interface{}, 0)
    rows, err := db.Query(sql)
    if err != nil {
        return nil, err
    }
    cols, err := rows.Columns()
    args := make([]interface{}, len(cols))
    scanArgs := make([]interface{}, len(cols))
    for i := range args {
        scanArgs[i] = &args[i]
    }
    for rows.Next() {
        if err := rows.Scan(scanArgs...); err != nil {
            return nil, err
        }
        row := make(map[string]interface{})
        for i, col := range args {
            if col == nil {
                row[cols[i]] = "null"
                continue
            }
            switch col.(type ) {
            case bool,int,int8,int16,int32,int64,uint,uint8,uint16,uint32,uint64,float32,float64:
                row[cols[i]] = col
            case time.Time:
                row[cols[i]] = col.(time.Time).Format("2006-01-02 15:04:05")
            default:
                row[cols[i]] = string(col.([]byte))
            }
        }
        res = append(res, row)
    }
    return res, nil
}

import web

class handle:
    def GET(self, pid):
        return

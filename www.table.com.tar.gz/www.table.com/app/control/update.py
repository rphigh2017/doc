import web

class handle:
    def POST(self, pid):
        return

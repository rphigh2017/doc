#include <iostream>
#include <algorithm>
#include <functional>
#include <boost/lambda/lambda.hpp>
#include <iterator>

using namespace std;

int main() {
    using namespace  boost::lambda;
    typedef std::istream_iterator<int> in;

    cout << "xxx" << endl;

    std::for_each(in(std::cin), in(), std::cout << (_1 * 3) << " ");

    cout << "yyy" << endl;

    return 0;
}

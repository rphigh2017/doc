#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

template <typename T>
class cprint {
  public:
    void operator()(const T& i) {
        cout << i << endl;
    }
};

int main() {
    int a[] = {0,1,2,3,4,5};
    vector<int> v(a, a+6);

    for_each(v.begin(), v.end(), cprint<int>());
}

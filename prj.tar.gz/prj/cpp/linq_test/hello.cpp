#include <iostream>
#include "cpplinq.hpp"

using namespace std;
using namespace cpplinq;

int sum_all() {
    int l[] = {3,1,4,1,5,9,2,6,5,4};

    return from_array (l)
        >> where ([](int i) { return i%2 == 0;})
        >> sum();
}

int main() {
    cout << sum_all() << endl;
}

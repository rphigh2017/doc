package main

import (
    "fmt"
)

const (
    x100 = 1
)

func fib(n int) int {
    switch {
    case n == 1:
        return 1
    case n == 2:
        return 2
    default:
        return fib(n-1) + fib(n-2)
    }
}

func main() {
    fmt.Println(fib(10))
    fmt.Println("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
    fmt.Println("a quick brown fox jumps over the lazy dog")
}

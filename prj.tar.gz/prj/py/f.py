#!/usr/bin/env python
# -*- coding: utf8 -*-

'''
testing
'''

A = range(0, 3)
B = range(6, 9)

L = [(x, y) for x in A for y in B]
print L

l = range(0, 6)
print map(lambda x: x, l)

def sum(seq):
    def add(x, y):
        return x+y
    return reduce(add, seq, 0)

print sum(range(0, 11))

ll = ['apple', 'orange', 'pear']
ls = set(ll)

from ctypes import *

class cmysql():
    NULL = POINTER(c_long)()
    class feilds(Structure):
        __feilds = [("name", c_char_p),
                ("org_name", c_char_p)]

    def __init__(self, path):
        self.C = cdll.LoadLibrary(path)
        self.C.mysql_error.restype = c_char_p
        self.handler = self.C.mysql_init(self.NULL)
        if self.handler == 0: raise Exception("%s" % self.C.mysql_error(self.conn))

    def connect(self, dsn):
        self.conn = self.C.mysql_real_connect(self.handler, dsn["host"],
                dsn["user"], dsn["pswd"], dsn["name"], dsn["port"], self.NULL,
                0)
        if self.handler == 0: raise Exception("%s" % self.C.mysql_error(self.conn))

    def write(self, sql):
        ret = self.C.mysql_real_query(self.conn, sql, len(sql))
        if ret != 0: raise Exception("%s" % self.C.mysql_error(self.conn))

    def read(self, sql):
        self.write(sql)
        res = self.C.mysql_store_result(self.conn)
        if res == 0: raise Exception("%s" % self.C.mysql_error(self.conn))

        nrow, ncol = self.C.mysql_num_rows(res), self.C.mysql_num_fields(res)
        self.C.mysql_fetch_fields.restype = POINTER(self.field_s)
        self.C.mysql_fetch_row.restype = POINTER(c_char_p)

        self.__fields__ = self.C.mysql_fetch_fields(res)
        self.__rows__ = [self.C.mysql_fetch_row(res) for i in range(nrow)]

        self.fields = [self.__fields__[i].name for i in range(ncol)]
        self.rows = [[row[j] for j in range(ncol)] for row in self.__rows__]

        self.C.mysql_free_rsult(res)

    def __del__(self):
        self.C.mysql_close(self.handler)

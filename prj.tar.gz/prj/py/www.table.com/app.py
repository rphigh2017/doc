"""
doc
"""

import web

def main():
    """ CRUD """
    urls = (
        "/home", "app.control.home.handle",
        "/help", "app.control.help.handle",
        "/([0-9]+)/create", "app.control.create.handle",
        "/([0-9]+)/retrieve", "app.control.retrieve.handle",
        "/([0-9]+)/update", "app.control.update.handle",
        "/([0-9]+)/delete", "app.control.delete.handle",
    )

    app = web.application(urls, globals())
    app.run()

if __name__ == "__main__":
    main()

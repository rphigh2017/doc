import web

view = web.template.render("app/view")

class handle:
    def GET(self):
        return view.home()

import web

db = web.database(dbn='sqlite', db='dbname')

create table t_tableid (
    id      integer
);
CREATE TABLE t_columnid (

);

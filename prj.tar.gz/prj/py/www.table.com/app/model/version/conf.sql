CREATE TABLE t_table (
    c_id        INTEGER PRIMARY KEY AUTOINCREAMENT,
    c_title     TEXT NOT NULL,
    c_table     TEXT NOT NULL,
    c_create    DATETIME DEFAULT (DATETIME('now', 'localtime')),
    c_modify    DATETIME DEFAULT (DATETIME('now', 'localtime')),
    c_order     TEXT NOT NULL DEFAULT '',
    UNIQUE(c_table)
);

CREATE TABLE t_column (
    c_id        INTEGER PRIMARY KEY AUTOINCREAMENT,
    c_table     INTEGER,
    c_desc1     TEXT NOT NULL,
    c_desc2     TEXT NOT NULL,
    c_create    DATETIME DEFAULT (DATETIME('now', 'localtime')),
    c_modify    DATETIME DEFAULT (DATETIME('now', 'localtime')),
    c_order     TEXT NOT NULL DEFAULT '',
    c_id
);

// Package lua is a port of the Lua VM from http://lua.org/ from C to Go.
package lua

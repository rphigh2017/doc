-- A file that should generate a syntax error

this_is_a_syntax_error

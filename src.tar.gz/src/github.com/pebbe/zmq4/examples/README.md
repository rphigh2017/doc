These are examples from [ØMQ - The Guide](http://zguide.zeromq.org/page:all), 
re-implemented for the current Go package.
